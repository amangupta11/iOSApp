//
//  AppDelegate.h
//  BeaconPOCAdminApp
//
//  Created by Aman Gupta on 21/06/16.
//  Copyright © 2016 Aman Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic) BOOL shouldVerifySystemSettings;

@end

