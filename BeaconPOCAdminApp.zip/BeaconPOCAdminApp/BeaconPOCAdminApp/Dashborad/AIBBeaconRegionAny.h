//
//  AIBBeaconRegionAny.h
//  AnyiBeacon
//
//  Created by Sandeep Mistry on 1/5/2014.
//  Copyright (c) 2014 Sandeep Mistry. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <CoreLocation/CoreLocation.h>

@interface AIBBeaconRegionAny : CLBeaconRegion

- (id)initWithIdentifier:(NSString *)identifier;

@end
