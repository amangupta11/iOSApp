//
//  BeaconDashboardTableViewCell.m
//  BeaconPoc
//
//  Created by Aman Gupta on 17/06/16.
//  Copyright © 2016 Aman Gupta. All rights reserved.
//

#import "BeaconDashboardTableViewCell.h"

@implementation BeaconDashboardTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
